"use server";

import * as dashboardService from "@/services/dashboardService";
import * as birthdayService from "@/services/birthdayService";
import { getCompanyTimezone } from "@/services/reportsService";
import { requireSession } from "@/services/sessionService";

export async function getDashboardSummaryAction() {
  const session = await requireSession();
  return dashboardService.getDashboardSummary(session);
}

export async function getEmployeesOnBreakAction() {
  const session = await requireSession();
  return dashboardService.getEmployeesOnBreak(session);
}

export async function getMyDashboardProfileAction() {
  const session = await requireSession();
  return dashboardService.getMyDashboardProfile(session);
}

export async function getMyDashboardStatsAction() {
  const session = await requireSession();
  return dashboardService.getMyDashboardStats(session);
}

export async function getMyAttendanceCalendarAction(year: number, month: number) {
  const session = await requireSession();
  return dashboardService.getMyAttendanceCalendar(session, year, month);
}

export async function getAdminAttendanceCalendarAction(year: number, month: number) {
  const session = await requireSession();
  return dashboardService.getAdminAttendanceCalendar(session, year, month);
}

export async function getShiftBreakdownAction() {
  const session = await requireSession();
  return dashboardService.getShiftBreakdown(session);
}

export async function getEmployeesWorkingAction() {
  const session = await requireSession();
  return dashboardService.getEmployeesWorking(session);
}

export async function getBirthdayCalendarAction(year: number, month: number) {
  await requireSession();
  const timezone = await getCompanyTimezone();
  return birthdayService.getBirthdaysForMonth(month, year, timezone);
}
