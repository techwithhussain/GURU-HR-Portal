"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { correctAttendanceAction } from "@/actions/attendance.actions";
import { TimePicker, type TimeState, initTime, toDate } from "@/features/reports/TimePicker";

const labelClass = "block text-xs font-medium text-muted-foreground mb-1.5";

const overlayClass =
  "fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm";

const dialogClass =
  "relative w-full max-w-lg rounded-2xl border border-border bg-background p-6 shadow-2xl space-y-5";

interface Props {
  attendanceId: string;
  employeeName: string;
  employeeCode: string;
  attendanceDate: string;
  currentCheckIn: string | null;
  currentCheckOut: string | null;
}

export function CorrectAttendanceDialog({
  attendanceId,
  employeeName,
  employeeCode,
  attendanceDate,
  currentCheckIn,
  currentCheckOut,
}: Props) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();

  const [checkIn, setCheckIn] = useState<TimeState>(initTime(currentCheckIn));
  const [checkOut, setCheckOut] = useState<TimeState>(initTime(currentCheckOut));
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);

  function handleOpen() {
    setCheckIn(initTime(currentCheckIn));
    setCheckOut(initTime(currentCheckOut));
    setReason("");
    setError(null);
    setOpen(true);
  }

  function handleSubmit() {
    const inDate = toDate(checkIn);
    const outDate = checkOut.enabled ? toDate(checkOut) : null;

    if (!inDate) {
      setError("Login time is required.");
      return;
    }
    if (!reason.trim()) {
      setError("A reason for the correction is required.");
      return;
    }
    setError(null);
    startTransition(async () => {
      const result = await correctAttendanceAction(attendanceId, {
        checkInAt: inDate,
        checkOutAt: outDate,
        reason: reason.trim(),
      });
      if (!result.success) {
        setError(result.error ?? "Correction failed. Please try again.");
        return;
      }
      toast.success("Attendance corrected successfully!");
      setOpen(false);
      router.refresh();
    });
  }

  return (
    <>
      <Button size="sm" variant="outline" onClick={handleOpen} className="gap-1.5 print:hidden">
        <Pencil className="size-3.5" />
        Correct Attendance
      </Button>

      {open && (
        <div className={overlayClass} onClick={() => !isPending && setOpen(false)}>
          <div className={dialogClass} onClick={(e) => e.stopPropagation()}>
            <div>
              <h2 className="text-base font-semibold">Correct Attendance</h2>
              <div className="mt-2 flex items-center gap-2 rounded-lg bg-muted/60 px-3 py-2">
                <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-orange to-brand-orange-light text-[11px] font-semibold text-white">
                  {employeeName
                    .trim()
                    .split(/\s+/)
                    .slice(0, 2)
                    .map((p) => p[0]?.toUpperCase() ?? "")
                    .join("")}
                </div>
                <div className="leading-tight">
                  <p className="text-sm font-semibold">{employeeName}</p>
                  <p className="text-xs text-muted-foreground">
                    {employeeCode} · {attendanceDate}
                  </p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Update the login/logout time and provide a reason for the correction.
              </p>
            </div>

            <div className="space-y-4">
              <TimePicker
                label="Login Time (corrected)"
                state={checkIn}
                onChange={setCheckIn}
                disabled={isPending}
                alwaysEnabled={true}
              />

              <TimePicker
                label="Logout Time (corrected)"
                state={checkOut}
                onChange={setCheckOut}
                disabled={isPending}
                hint="Uncheck Logout if you only need to correct the login time (leaves session open)."
              />

              <div>
                <label className={labelClass}>Reason for Correction *</label>
                <textarea
                  className="min-h-20 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm outline-none transition-colors placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 resize-none"
                  placeholder="e.g. Employee logged in late due to night shift start time..."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  disabled={isPending}
                />
              </div>

              {error && (
                <p className="text-xs text-destructive rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2">
                  {error}
                </p>
              )}
            </div>

            <div className="flex gap-2 justify-end pt-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setOpen(false)}
                disabled={isPending}
              >
                Cancel
              </Button>
              <Button size="sm" onClick={handleSubmit} disabled={isPending}>
                {isPending ? "Saving..." : "Save Correction"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
